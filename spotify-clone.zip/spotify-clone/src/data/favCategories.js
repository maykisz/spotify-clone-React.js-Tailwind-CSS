export default [
	{
		id: 1,
		title: 'M.A.D 2',
		cover: 'https://akamai.sscdn.co/uploadfile/letras/albuns/d/4/2/4/2085331724845174.jpg',
		color: '#6d6642ff'
	},
	{
		id: 2,
		title: '808 Club',
		cover: 'https://akamai.sscdn.co/uploadfile/letras/albuns/e/e/2/e/2619901738330293.jpg',
		color: '#b60e9fff'
	},
	{
		id: 3,
		title: 'Caos',
		cover: 'https://cdn-images.dzcdn.net/images/cover/e266a4ed913704ef387f8678f72839a4/0x1900-000000-80-0-0.jpg',
		color: '#921818ff'
	},
	{
		id: 4,
		title: 'É Que Eu Nasci Teimoso',
		cover: 'https://akamai.sscdn.co/letras/360x360/albuns/3/3/e/8/2396241728335115.jpg',
		color: '#8a8b94ff'
	},
	{
		id: 5,
		title: '333',
		cover: 'https://akamai.sscdn.co/uploadfile/letras/albuns/2/e/4/3/2365061725960029.jpg',
		color: '#0855baff'
	}
]