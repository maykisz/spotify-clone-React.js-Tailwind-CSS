import { useState } from 'react'
import { Icon } from 'Icons'
import { Dialog } from '@headlessui/react'

export default function MyDialog() {
    let [isOpen, setIsOpen] = useState(true)
}